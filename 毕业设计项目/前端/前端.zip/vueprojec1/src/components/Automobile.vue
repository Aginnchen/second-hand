<template>
  <div id="tab">
    <div class="container">
      <div class="text"><span>热卖车型</span></div>
      <div class="tabList">
        <div class="ul">
          <p class="cur"><span>猜你喜欢</span></p>
          <p><span>严选车</span></p>
          <p><span>最新上架</span></p>
          <p><span>降价急售</span></p>
          <p><span>准新车</span></p>
          <p><span>练手车</span></p>
          <p><span>SUV</span></p>
        </div>
      </div>
      <div class="tabCon">
        <div class="div cur">
          <ul class="ul">
            <li class="li">

              <img src="../assets/imgs/长安.jpg" height="190" width="260"/>
          <p class="p1">长安 逸动DT 2018款 1.6L 自动智享型</p>
              <span class="span2">2016年|2.4万公里|到店服务</span>
              <p class="p2">5.94万     <del class="del">7.80万</del></p>

              <a class="forgetLink" href="https://www.guazi.com/hz/changan/#bread" >查看详情》</a>
            </li>


            <li class="li"> <img src="../assets/imgs/长安2.jpg" height="190" width="260"/>
              <p class="p1">长安 逸动 2018款 1.6L GDI 手动风潮型 国V</p>
              <span class="span2">2016年|2.4万公里|到店服务</span>
              <p class="p2">15.94万     <del class="del">17.80万</del></p>

              <a class="forgetLink" href="https://www.guazi.com/hz/changan/#bread" >查看详情》</a></li>
            <li class="li"> <img src="../assets/imgs/大众.jpg" height="190" width="260"/>
              <p class="p1">大众 途观 2015款 1.8TSI 自动两驱豪华型</p>
              <span class="span2">2016年|2.4万公里|到店服务</span>
              <p class="p2">13.94万     <del class="del">28.80万</del></p>

              <a class="forgetLink" href="https://www.guazi.com/hz/changan/#bread" >查看详情》</a></li>
            <li class="li"> <img src="../assets/imgs/哈.jpg" height="190" width="260"/>
              <p class="p1">大众 途观 2015款 1.8TSI 自动两驱豪华型</p>
              <span class="span2">2016年|2.4万公里|到店服务</span>
              <p class="p2">13.94万     <del class="del">28.80万</del></p>

              <a class="forgetLink" href="https://www.guazi.com/hz/changan/#bread" >查看详情》</a></li>
            <li class="li"><img src="../assets/imgs/东风.jpg" height="190" width="260"/>
              <p class="p1">大众 途观 2015款 1.8TSI 自动两驱豪华型</p>
              <span class="span2">2016年|2.4万公里|到店服务</span>
              <p class="p2">13.94万     <del class="del">28.80万</del></p>

              <a class="forgetLink" href="https://www.guazi.com/hz/changan/#bread" >查看详情》</a></li>
            <li class="li"><img src="../assets/imgs/东风.jpg" height="190" width="260"/>
              <p class="p1">东风风光S560 2018款 1.8L CVT都市型 5座</p>
              <span class="span2">2016年|2.4万公里|到店服务</span>
              <p class="p2">13.94万     <del class="del">28.80万</del></p>

              <a class="forgetLink" href="https://www.guazi.com/hz/changan/#bread" >查看详情》</a></li>
            <li class="li"><img src="../assets/imgs/别克.jpg" height="190" width="260"/>
              <p class="p1">别克 凯越 2011款 1.6LE-AT</p>
              <span class="span2">2016年|2.4万公里|到店服务</span>
              <p class="p2">13.94万     <del class="del">28.80万</del></p>

              <a class="forgetLink" href="https://www.guazi.com/hz/changan/#bread" >查看详情》</a></li>
            <li class="li"><img src="../assets/imgs/别克.jpg" height="190" width="260"/>
              <p class="p1">雪铁龙C3-XR 2015款 1.6L 自动时尚型</p>
              <span class="span2">2016年|2.4万公里|到店服务</span>
              <p class="p2">13.94万     <del class="del">28.80万</del></p>

              <a class="forgetLink" href="https://www.guazi.com/hz/changan/#bread" >查看详情》</a></li>
            <li class="li"><img src="../assets/imgs/东风.jpg" height="190" width="260"/>
              <p class="p1">大众 途观 2015款 1.8TSI 自动两驱豪华型</p>
              <span class="span2">2016年|2.4万公里|到店服务</span>
              <p class="p2">13.94万     <del class="del">28.80万</del></p>

              <a class="forgetLink" href="https://www.guazi.com/hz/changan/#bread" >查看详情》</a></li>
            <li class="li"><img src="../assets/imgs/东风.jpg" height="190" width="260"/>
              <p class="p1">大众 途观 2015款 1.8TSI 自动两驱豪华型</p>
              <span class="span2">2016年|2.4万公里|到店服务</span>
              <p class="p2">13.94万     <del class="del">28.80万</del></p>

              <a class="forgetLink" href="https://www.guazi.com/hz/changan/#bread" >查看详情》</a></li>
          </ul>
        </div>
        <div class="div">
          <ul class="ul">
            <li class="li"><img src="../assets/imgs/别克.jpg" height="190" width="260"/>
              <p class="p1">雪铁龙C3-XR 2015款 1.6L 自动时尚型</p>
              <span class="span2">2016年|2.4万公里|到店服务</span>
              <p class="p2">13.94万     <del class="del">28.80万</del></p>

              <a class="forgetLink" href="https://www.guazi.com/hz/changan/#bread" >查看详情》</a></li>


            <li class="li"> <img src="../assets/imgs/长安2.jpg" height="190" width="260"/>
              <p class="p1">长安 逸动 2018款 1.6L GDI 手动风潮型 国V</p>
              <span class="span2">2016年|2.4万公里|到店服务</span>
              <p class="p2">15.94万     <del class="del">17.80万</del></p>

              <a class="forgetLink" href="https://www.guazi.com/hz/changan/#bread" >查看详情》</a></li>
            <li class="li"> <img src="../assets/imgs/大众.jpg" height="190" width="260"/>
              <p class="p1">大众 途观 2015款 1.8TSI 自动两驱豪华型</p>
              <span class="span2">2016年|2.4万公里|到店服务</span>
              <p class="p2">13.94万     <del class="del">28.80万</del></p>

              <a class="forgetLink" href="https://www.guazi.com/hz/changan/#bread" >查看详情》</a></li>
            <li class="li"> <img src="../assets/imgs/哈.jpg" height="190" width="260"/>
              <p class="p1">大众 途观 2015款 1.8TSI 自动两驱豪华型</p>
              <span class="span2">2016年|2.4万公里|到店服务</span>
              <p class="p2">13.94万     <del class="del">28.80万</del></p>

              <a class="forgetLink" href="https://www.guazi.com/hz/changan/#bread" >查看详情》</a></li>
            <li class="li"><img src="../assets/imgs/东风.jpg" height="190" width="260"/>
              <p class="p1">大众 途观 2015款 1.8TSI 自动两驱豪华型</p>
              <span class="span2">2016年|2.4万公里|到店服务</span>
              <p class="p2">13.94万     <del class="del">28.80万</del></p>

              <a class="forgetLink" href="https://www.guazi.com/hz/changan/#bread" >查看详情》</a></li>
            <li class="li"><img src="../assets/imgs/东风.jpg" height="190" width="260"/>
              <p class="p1">东风风光S560 2018款 1.8L CVT都市型 5座</p>
              <span class="span2">2016年|2.4万公里|到店服务</span>
              <p class="p2">13.94万     <del class="del">28.80万</del></p>

              <a class="forgetLink" href="https://www.guazi.com/hz/changan/#bread" >查看详情》</a></li>
            <li class="li"><img src="../assets/imgs/别克.jpg" height="190" width="260"/>
              <p class="p1">别克 凯越 2011款 1.6LE-AT</p>
              <span class="span2">2016年|2.4万公里|到店服务</span>
              <p class="p2">13.94万     <del class="del">28.80万</del></p>

              <a class="forgetLink" href="https://www.guazi.com/hz/changan/#bread" >查看详情》</a></li>
            <li class="li"><img src="../assets/imgs/别克.jpg" height="190" width="260"/>
              <p class="p1">雪铁龙C3-XR 2015款 1.6L 自动时尚型</p>
              <span class="span2">2016年|2.4万公里|到店服务</span>
              <p class="p2">13.94万     <del class="del">28.80万</del></p>

              <a class="forgetLink" href="https://www.guazi.com/hz/changan/#bread" >查看详情》</a></li>

          </ul>
        </div>
        <div class="div">
          <ul class="ul">
            <li class="li"> <img src="../assets/imgs/长安2.jpg" height="190" width="260"/>
              <p class="p1">长安 逸动 2018款 1.6L GDI 手动风潮型 国V</p>
              <span class="span2">2016年|2.4万公里|到店服务</span>
              <p class="p2">15.94万     <del class="del">17.80万</del></p>

              <a class="forgetLink" href="https://www.guazi.com/hz/changan/#bread" >查看详情》</a></li>


            <li class="li"> <img src="../assets/imgs/长安2.jpg" height="190" width="260"/>
              <p class="p1">长安 逸动 2018款 1.6L GDI 手动风潮型 国V</p>
              <span class="span2">2016年|2.4万公里|到店服务</span>
              <p class="p2">15.94万     <del class="del">17.80万</del></p>

              <a class="forgetLink" href="https://www.guazi.com/hz/changan/#bread" >查看详情》</a></li>
            <li class="li"> <img src="../assets/imgs/大众.jpg" height="190" width="260"/>
              <p class="p1">大众 途观 2015款 1.8TSI 自动两驱豪华型</p>
              <span class="span2">2016年|2.4万公里|到店服务</span>
              <p class="p2">13.94万     <del class="del">28.80万</del></p>

              <a class="forgetLink" href="https://www.guazi.com/hz/changan/#bread" >查看详情》</a></li>
            <li class="li"> <img src="../assets/imgs/哈.jpg" height="190" width="260"/>
              <p class="p1">大众 途观 2015款 1.8TSI 自动两驱豪华型</p>
              <span class="span2">2016年|2.4万公里|到店服务</span>
              <p class="p2">13.94万     <del class="del">28.80万</del></p>

              <a class="forgetLink" href="https://www.guazi.com/hz/changan/#bread" >查看详情》</a></li>
            <li class="li"><img src="../assets/imgs/东风.jpg" height="190" width="260"/>
              <p class="p1">大众 途观 2015款 1.8TSI 自动两驱豪华型</p>
              <span class="span2">2016年|2.4万公里|到店服务</span>
              <p class="p2">13.94万     <del class="del">28.80万</del></p>

              <a class="forgetLink" href="https://www.guazi.com/hz/changan/#bread" >查看详情》</a></li>
            <li class="li"><img src="../assets/imgs/东风.jpg" height="190" width="260"/>
              <p class="p1">东风风光S560 2018款 1.8L CVT都市型 5座</p>
              <span class="span2">2016年|2.4万公里|到店服务</span>
              <p class="p2">13.94万     <del class="del">28.80万</del></p>

              <a class="forgetLink" href="https://www.guazi.com/hz/changan/#bread" >查看详情》</a></li>
            <li class="li"><img src="../assets/imgs/别克.jpg" height="190" width="260"/>
              <p class="p1">别克 凯越 2011款 1.6LE-AT</p>
              <span class="span2">2016年|2.4万公里|到店服务</span>
              <p class="p2">13.94万     <del class="del">28.80万</del></p>

              <a class="forgetLink" href="https://www.guazi.com/hz/changan/#bread" >查看详情》</a></li>
            <li class="li"><img src="../assets/imgs/别克.jpg" height="190" width="260"/>
              <p class="p1">雪铁龙C3-XR 2015款 1.6L 自动时尚型</p>
              <span class="span2">2016年|2.4万公里|到店服务</span>
              <p class="p2">13.94万     <del class="del">28.80万</del></p>

              <a class="forgetLink" href="https://www.guazi.com/hz/changan/#bread" >查看详情》</a></li>
          </ul>
        </div>
        <div class="div">
          <ul class="ul">
            <li class="li">

              <img src="../assets/imgs/长安.jpg" height="190" width="260"/>
              <p class="p1">长安 逸动DT 2018款 1.6L 自动智享型</p>
              <span class="span2">2016年|2.4万公里|到店服务</span>
              <p class="p2">5.94万     <del class="del">7.80万</del></p>

              <a class="forgetLink" href="https://www.guazi.com/hz/changan/#bread" >查看详情》</a>
            </li>


            <li class="li"> <img src="../assets/imgs/长安2.jpg" height="190" width="260"/>
              <p class="p1">长安 逸动 2018款 1.6L GDI 手动风潮型 国V</p>
              <span class="span2">2016年|2.4万公里|到店服务</span>
              <p class="p2">15.94万     <del class="del">17.80万</del></p>

              <a class="forgetLink" href="https://www.guazi.com/hz/changan/#bread" >查看详情》</a></li>
            <li class="li"> <img src="../assets/imgs/大众.jpg" height="190" width="260"/>
              <p class="p1">大众 途观 2015款 1.8TSI 自动两驱豪华型</p>
              <span class="span2">2016年|2.4万公里|到店服务</span>
              <p class="p2">13.94万     <del class="del">28.80万</del></p>

              <a class="forgetLink" href="https://www.guazi.com/hz/changan/#bread" >查看详情》</a></li>
            <li class="li"> <img src="../assets/imgs/哈.jpg" height="190" width="260"/>
              <p class="p1">大众 途观 2015款 1.8TSI 自动两驱豪华型</p>
              <span class="span2">2016年|2.4万公里|到店服务</span>
              <p class="p2">13.94万     <del class="del">28.80万</del></p>

              <a class="forgetLink" href="https://www.guazi.com/hz/changan/#bread" >查看详情》</a></li>
            <li class="li"><img src="../assets/imgs/东风.jpg" height="190" width="260"/>
              <p class="p1">大众 途观 2015款 1.8TSI 自动两驱豪华型</p>
              <span class="span2">2016年|2.4万公里|到店服务</span>
              <p class="p2">13.94万     <del class="del">28.80万</del></p>

              <a class="forgetLink" href="https://www.guazi.com/hz/changan/#bread" >查看详情》</a></li>
            <li class="li"><img src="../assets/imgs/东风.jpg" height="190" width="260"/>
              <p class="p1">东风风光S560 2018款 1.8L CVT都市型 5座</p>
              <span class="span2">2016年|2.4万公里|到店服务</span>
              <p class="p2">13.94万     <del class="del">28.80万</del></p>

              <a class="forgetLink" href="https://www.guazi.com/hz/changan/#bread" >查看详情》</a></li>
            <li class="li"><img src="../assets/imgs/别克.jpg" height="190" width="260"/>
              <p class="p1">别克 凯越 2011款 1.6LE-AT</p>
              <span class="span2">2016年|2.4万公里|到店服务</span>
              <p class="p2">13.94万     <del class="del">28.80万</del></p>

              <a class="forgetLink" href="https://www.guazi.com/hz/changan/#bread" >查看详情》</a></li>
            <li class="li"><img src="../assets/imgs/别克.jpg" height="190" width="260"/>
              <p class="p1">雪铁龙C3-XR 2015款 1.6L 自动时尚型</p>
              <span class="span2">2016年|2.4万公里|到店服务</span>
              <p class="p2">13.94万     <del class="del">28.80万</del></p>

              <a class="forgetLink" href="https://www.guazi.com/hz/changan/#bread" >查看详情》</a></li>

          </ul>
        </div>
        <div class="div">
          <ul class="ul">
            <li class="li">

              <img src="../assets/imgs/长安.jpg" height="190" width="260"/>
              <p class="p1">长安 逸动DT 2018款 1.6L 自动智享型</p>
              <span class="span2">2016年|2.4万公里|到店服务</span>
              <p class="p2">5.94万     <del class="del">7.80万</del></p>

              <a class="forgetLink" href="https://www.guazi.com/hz/changan/#bread" >查看详情》</a>
            </li>


            <li class="li"> <img src="../assets/imgs/长安2.jpg" height="190" width="260"/>
              <p class="p1">长安 逸动 2018款 1.6L GDI 手动风潮型 国V</p>
              <span class="span2">2016年|2.4万公里|到店服务</span>
              <p class="p2">15.94万     <del class="del">17.80万</del></p>

              <a class="forgetLink" href="https://www.guazi.com/hz/changan/#bread" >查看详情》</a></li>
            <li class="li"> <img src="../assets/imgs/大众.jpg" height="190" width="260"/>
              <p class="p1">大众 途观 2015款 1.8TSI 自动两驱豪华型</p>
              <span class="span2">2016年|2.4万公里|到店服务</span>
              <p class="p2">13.94万     <del class="del">28.80万</del></p>

              <a class="forgetLink" href="https://www.guazi.com/hz/changan/#bread" >查看详情》</a></li>
            <li class="li"> <img src="../assets/imgs/哈.jpg" height="190" width="260"/>
              <p class="p1">大众 途观 2015款 1.8TSI 自动两驱豪华型</p>
              <span class="span2">2016年|2.4万公里|到店服务</span>
              <p class="p2">13.94万     <del class="del">28.80万</del></p>

              <a class="forgetLink" href="https://www.guazi.com/hz/changan/#bread" >查看详情》</a></li>
            <li class="li"><img src="../assets/imgs/东风.jpg" height="190" width="260"/>
              <p class="p1">大众 途观 2015款 1.8TSI 自动两驱豪华型</p>
              <span class="span2">2016年|2.4万公里|到店服务</span>
              <p class="p2">13.94万     <del class="del">28.80万</del></p>

              <a class="forgetLink" href="https://www.guazi.com/hz/changan/#bread" >查看详情》</a></li>
            <li class="li"><img src="../assets/imgs/东风.jpg" height="190" width="260"/>
              <p class="p1">东风风光S560 2018款 1.8L CVT都市型 5座</p>
              <span class="span2">2016年|2.4万公里|到店服务</span>
              <p class="p2">13.94万     <del class="del">28.80万</del></p>

              <a class="forgetLink" href="https://www.guazi.com/hz/changan/#bread" >查看详情》</a></li>
            <li class="li"><img src="../assets/imgs/别克.jpg" height="190" width="260"/>
              <p class="p1">别克 凯越 2011款 1.6LE-AT</p>
              <span class="span2">2016年|2.4万公里|到店服务</span>
              <p class="p2">13.94万     <del class="del">28.80万</del></p>

              <a class="forgetLink" href="https://www.guazi.com/hz/changan/#bread" >查看详情》</a></li>
            <li class="li"><img src="../assets/imgs/别克.jpg" height="190" width="260"/>
              <p class="p1">雪铁龙C3-XR 2015款 1.6L 自动时尚型</p>
              <span class="span2">2016年|2.4万公里|到店服务</span>
              <p class="p2">13.94万     <del class="del">28.80万</del></p>

              <a class="forgetLink" href="https://www.guazi.com/hz/changan/#bread" >查看详情》</a></li>
          </ul>
        </div>
        <div class="div">
          <ul class="ul">
            <li class="li">

              <img src="../assets/imgs/长安.jpg" height="190" width="260"/>
              <p class="p1">长安 逸动DT 2018款 1.6L 自动智享型</p>
              <span class="span2">2016年|2.4万公里|到店服务</span>
              <p class="p2">5.94万     <del class="del">7.80万</del></p>

              <a class="forgetLink" href="https://www.guazi.com/hz/changan/#bread" >查看详情》</a>
            </li>


            <li class="li"> <img src="../assets/imgs/长安2.jpg" height="190" width="260"/>
              <p class="p1">长安 逸动 2018款 1.6L GDI 手动风潮型 国V</p>
              <span class="span2">2016年|2.4万公里|到店服务</span>
              <p class="p2">15.94万     <del class="del">17.80万</del></p>

              <a class="forgetLink" href="https://www.guazi.com/hz/changan/#bread" >查看详情》</a></li>
            <li class="li"> <img src="../assets/imgs/大众.jpg" height="190" width="260"/>
              <p class="p1">大众 途观 2015款 1.8TSI 自动两驱豪华型</p>
              <span class="span2">2016年|2.4万公里|到店服务</span>
              <p class="p2">13.94万     <del class="del">28.80万</del></p>

              <a class="forgetLink" href="https://www.guazi.com/hz/changan/#bread" >查看详情》</a></li>
            <li class="li"> <img src="../assets/imgs/哈.jpg" height="190" width="260"/>
              <p class="p1">大众 途观 2015款 1.8TSI 自动两驱豪华型</p>
              <span class="span2">2016年|2.4万公里|到店服务</span>
              <p class="p2">13.94万     <del class="del">28.80万</del></p>

              <a class="forgetLink" href="https://www.guazi.com/hz/changan/#bread" >查看详情》</a></li>
            <li class="li"><img src="../assets/imgs/东风.jpg" height="190" width="260"/>
              <p class="p1">大众 途观 2015款 1.8TSI 自动两驱豪华型</p>
              <span class="span2">2016年|2.4万公里|到店服务</span>
              <p class="p2">13.94万     <del class="del">28.80万</del></p>

              <a class="forgetLink" href="https://www.guazi.com/hz/changan/#bread" >查看详情》</a></li>
            <li class="li"><img src="../assets/imgs/东风.jpg" height="190" width="260"/>
              <p class="p1">东风风光S560 2018款 1.8L CVT都市型 5座</p>
              <span class="span2">2016年|2.4万公里|到店服务</span>
              <p class="p2">13.94万     <del class="del">28.80万</del></p>

              <a class="forgetLink" href="https://www.guazi.com/hz/changan/#bread" >查看详情》</a></li>
            <li class="li"><img src="../assets/imgs/别克.jpg" height="190" width="260"/>
              <p class="p1">别克 凯越 2011款 1.6LE-AT</p>
              <span class="span2">2016年|2.4万公里|到店服务</span>
              <p class="p2">13.94万     <del class="del">28.80万</del></p>

              <a class="forgetLink" href="https://www.guazi.com/hz/changan/#bread" >查看详情》</a></li>
            <li class="li"><img src="../assets/imgs/别克.jpg" height="190" width="260"/>
              <p class="p1">雪铁龙C3-XR 2015款 1.6L 自动时尚型</p>
              <span class="span2">2016年|2.4万公里|到店服务</span>
              <p class="p2">13.94万     <del class="del">28.80万</del></p>

              <a class="forgetLink" href="https://www.guazi.com/hz/changan/#bread" >查看详情》</a></li>
          </ul>
        </div>
        <div class="div">
          <ul class="ul">
            <li class="li">

              <img src="../assets/imgs/长安.jpg" height="190" width="260"/>
              <p class="p1">长安 逸动DT 2018款 1.6L 自动智享型</p>
              <span class="span2">2016年|2.4万公里|到店服务</span>
              <p class="p2">5.94万     <del class="del">7.80万</del></p>

              <a class="forgetLink" href="https://www.guazi.com/hz/changan/#bread" >查看详情》</a>
            </li>


            <li class="li"> <img src="../assets/imgs/长安2.jpg" height="190" width="260"/>
              <p class="p1">长安 逸动 2018款 1.6L GDI 手动风潮型 国V</p>
              <span class="span2">2016年|2.4万公里|到店服务</span>
              <p class="p2">15.94万     <del class="del">17.80万</del></p>

              <a class="forgetLink" href="https://www.guazi.com/hz/changan/#bread" >查看详情》</a></li>
            <li class="li"> <img src="../assets/imgs/大众.jpg" height="190" width="260"/>
              <p class="p1">大众 途观 2015款 1.8TSI 自动两驱豪华型</p>
              <span class="span2">2016年|2.4万公里|到店服务</span>
              <p class="p2">13.94万     <del class="del">28.80万</del></p>

              <a class="forgetLink" href="https://www.guazi.com/hz/changan/#bread" >查看详情》</a></li>
            <li class="li"> <img src="../assets/imgs/哈.jpg" height="190" width="260"/>
              <p class="p1">大众 途观 2015款 1.8TSI 自动两驱豪华型</p>
              <span class="span2">2016年|2.4万公里|到店服务</span>
              <p class="p2">13.94万     <del class="del">28.80万</del></p>

              <a class="forgetLink" href="https://www.guazi.com/hz/changan/#bread" >查看详情》</a></li>
            <li class="li"><img src="../assets/imgs/东风.jpg" height="190" width="260"/>
              <p class="p1">大众 途观 2015款 1.8TSI 自动两驱豪华型</p>
              <span class="span2">2016年|2.4万公里|到店服务</span>
              <p class="p2">13.94万     <del class="del">28.80万</del></p>

              <a class="forgetLink" href="https://www.guazi.com/hz/changan/#bread" >查看详情》</a></li>
            <li class="li"><img src="../assets/imgs/东风.jpg" height="190" width="260"/>
              <p class="p1">东风风光S560 2018款 1.8L CVT都市型 5座</p>
              <span class="span2">2016年|2.4万公里|到店服务</span>
              <p class="p2">13.94万     <del class="del">28.80万</del></p>

              <a class="forgetLink" href="https://www.guazi.com/hz/changan/#bread" >查看详情》</a></li>
            <li class="li"><img src="../assets/imgs/别克.jpg" height="190" width="260"/>
              <p class="p1">别克 凯越 2011款 1.6LE-AT</p>
              <span class="span2">2016年|2.4万公里|到店服务</span>
              <p class="p2">13.94万     <del class="del">28.80万</del></p>

              <a class="forgetLink" href="https://www.guazi.com/hz/changan/#bread" >查看详情》</a></li>
            <li class="li"><img src="../assets/imgs/别克.jpg" height="190" width="260"/>
              <p class="p1">雪铁龙C3-XR 2015款 1.6L 自动时尚型</p>
              <span class="span2">2016年|2.4万公里|到店服务</span>
              <p class="p2">13.94万     <del class="del">28.80万</del></p>

              <a class="forgetLink" href="https://www.guazi.com/hz/changan/#bread" >查看详情》</a></li>

          </ul>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  window.onload = function() {
    var oDiv = document.getElementById("tab");
    var oLi = oDiv.getElementsByClassName("tabList")[0].getElementsByTagName("p");
    var aCon = oDiv.getElementsByClassName("tabCon")[0].getElementsByTagName("div");
    var timer = null;
    for (var i = 0; i < oLi.length; i++) {
      oLi[i].index = i;
      oLi[i].onmouseover = function() {
        show(this.index);
      }
    }

    function show(a) {
      index = a;
      var alpha = 0;
      for (var j = 0; j < oLi.length; j++) {
        oLi[j].className = "";
        aCon[j].className = "";
        aCon[j].style.opacity = 0;
        aCon[j].style.filter = "alpha(opacity=0)";
      }
      oLi[index].className = "cur";
      clearInterval(timer);
      timer = setInterval(function() {
        alpha += 2;
        alpha > 100 && (alpha = 100);
        aCon[index].style.opacity = alpha / 100;
        aCon[index].style.filter = "alpha(opacity=" + alpha + ")";
        alpha == 100 && clearInterval(timer);
      }, 5)
    }
  }
</script>


<style >
  * {
    margin: 0;
    padding: 0;
  }

  body {
    font-size: 14px;
    font-family: "Microsoft YaHei";
  }

  ul,li {
    list-style: none;
  }

  #tab {
    position: relative;
    width: 100%;
    height: 100%;
    /*background: #f5f5f7;*/
  }

  #tab .container {
    width: 95%;
    height: 100%;
    margin-left: auto;
    margin-right: auto;
  }

  #tab .container .text {
    font-size: 28px;
    color: #000;
    width: 1200px;
    line-height: 10px;
    margin: 0 auto;
    padding-top: 22.5px;
margin-left: -0px;
  }

  #tab .container .tabList .ul {
    width: 100%;
    padding-top: 30px;
    padding-bottom: 17.5px;
    height: 10.5px;
    margin: 0 auto;
  }

  #tab .container .tabList .ul p {
    float: left;
    display: inline-block;
    margin-right: 28px;
    font-size: 16px;
    color: #999;
    cursor: pointer;
    line-height: 16px;
  }

  #tab .container .tabList .ul p span {
    display: inline-block;
    adding-bottom: 40px;
  }
  #tab .container .tabList .ul p:hover {
    color: #000000;
    background: #f5f5f7;
  }
  #tab .tabCon {
    display: block;
    width: 100%;
    height: 100%;
    border: 1px solid #000000;
    padding-left: 30px;
  }

  #tab .tabCon div {
    position: absolute;
    width: 100%;
    height:  100%;
    opacity: 0;
    filter: alpha(opacity=0);
  }

  #tab .tabList li.cur {
    border-bottom: none;
  }

  #tab .tabCon div.cur {
    opacity: 2;
    filter: alpha(opacity=100);
  }
  #tab .tabCon div .ul {
    width: 100%;
    height: 100%;
  }
  #tab .tabCon div .ul .li {
    margin-left: 40px;
    margin-bottom: 20px;
    background: #e6e6e6;
    float: left;
    width: 260px;
    height: 319px;
  }
  /*里面布局*/
  .span2{

  }
  .p1{
    font-size: 15px;
margin-top: 10px;
  }
  .span2{
    position: absolute;
    color:
      #a5abb2;
    font-size: 14px;
  }

  .p2{

    font-size: 20px;

    margin-top: 20px;
    color:#f95523;
  }
  .del{

  font-size: 14px;
  color: black;
  }

  /*查看*/
  .forgetLink{
    text-decoration: none;
    color: red;
    margin-top: 7px;
    text-decoration: none;
    float: right;
  }
  /*.imgshangou1{*/
  /*position: absolute;*/
  /*background-color: #ffffff;*/
  /*width: 250px;*/
  /*height: 370px;*/
  /*margin-left: 60px;*/
  /*}*/
  /*.h2{*/
  /*color: #495056;*/
  /*font-size: 17px;*/

  /*}*/
  /*.p1{*/
  /*color:*/
  /*#a5abb2;*/
  /*font-size: 14px;*/
  /*padding-left: 4px;*/
  /*padding-bottom: 2px;*/
  /*text-align: center;*/
  /*}*/
  /*.span2{*/
  /*height: 30px;*/
  /*font-size: 20px;*/
  /*color: #fa5428;*/
  /*margin: 15px;*/
  /*}*/

  /*.right{*/
  /*color: black;*/
  /*text-decoration: none;*/
  /*float: right;*/
  /*}*/

  /*.index-carlist-title{*/
  /*font-size: 28px;*/
  /*color:*/
  /*#000;*/
  /*width: 1200px;*/
  /*line-height: 28px;*/
  /*margin: 0 auto;*/
  /*padding-top: 52.5px;*/
  /*}*/
  /*span{*/
  /*margin: 0 auto;*/
  /*}*/

</style>
